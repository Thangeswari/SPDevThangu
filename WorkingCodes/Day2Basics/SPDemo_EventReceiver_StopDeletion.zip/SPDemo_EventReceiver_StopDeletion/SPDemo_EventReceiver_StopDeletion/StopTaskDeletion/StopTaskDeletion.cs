﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace SPDemo_EventReceiver_StopDeletion.StopTaskDeletion
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class StopTaskDeletion : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being deleted.
        /// </summary>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
            properties.ErrorMessage = "Sorry, items in task list cannot be deleted";
            properties.Cancel = true;
        }


    }
}