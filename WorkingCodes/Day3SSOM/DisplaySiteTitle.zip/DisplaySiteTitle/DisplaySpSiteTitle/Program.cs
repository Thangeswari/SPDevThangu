﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;

namespace DisplaySpSiteTitle
{
    class Program
    {
        static void Main(string[] args)
        {
            //Uri siteUri = new Uri("https://pentechs.sharepoint.com/sites/Coke");
            Console.WriteLine("Please enter the site Url");
            string strUrl = Console.ReadLine();
            Uri siteUri = new Uri(strUrl);
            string realm = TokenHelper.GetRealmFromTargetUrl(siteUri);
            string accessToken =
              TokenHelper.GetAppOnlyAccessToken(TokenHelper.SharePointPrincipal,
             siteUri.Authority, realm).AccessToken;
            using (var clientContext =
              TokenHelper.GetClientContextWithAccessToken(siteUri.ToString(),
              accessToken))
            {
                ReadSiteTitle(clientContext);
            }
            Console.ReadLine();
        }

        private static void ReadSiteTitle(ClientContext clientContext)
        {
            Web currentWeb = clientContext.Web;
            clientContext.Load(currentWeb);
            clientContext.ExecuteQuery();
            Console.WriteLine(currentWeb.Title);
        }
    }
}
